﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class FormHorista : Form
    {
        public FormHorista()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = textBox2.Text;
            objHorista.Matricula = Convert.ToInt32(textBox1.Text);
            objHorista.SalarioHora = Convert.ToDouble(textBox3.Text);
            objHorista.NumeroHora = Convert.ToDouble(textBox4.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(textBox5.Text);
            objHorista.DiasFalta = Convert.ToInt32(textBox6.Text);

            MessageBox.Show("Nome:" + objHorista.NomeEmpregado +
                "\n" + "Matricula:" + objHorista.Matricula + "\n" +
                "Tempo Trabalho:" + objHorista.TempoTrabalho().ToString()
               + "\n" + "Salário" + objHorista.SalarioBruto().ToString("N2"));
        }
    }
}
