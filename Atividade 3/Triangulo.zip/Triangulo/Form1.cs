﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Resultado : Form
    {
        public Resultado()
        {
            InitializeComponent();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            int tamA, tamB, tamC;

            this.label4.Focus();

            if (int.TryParse(A.Text, out tamA) && int.TryParse(B.Text, out tamB) && int.TryParse(C.Text, out tamC))
            {
                if ((Math.Abs(tamB - tamC) < tamA && tamA < (tamB + tamC)) && (Math.Abs(tamA - tamC) < tamB && tamA < (tamA + tamC)) && (Math.Abs(tamA - tamB) < tamC && tamA < (tamA + tamB)))
                {
                    //Fazer os testes:
                    if (tamA == tamB && tamA == tamC)
                    {
                        this.Resultadow.Text = "Equilátero";
                    }
                    else if ((tamA == tamB && tamA != tamC) || (tamA == tamC && tamA != tamB) || (tamB == tamC && tamB != tamA))
                    {
                        this.Resultadow.Text = "Isósceles";
                    }
                    else
                    {
                        this.Resultadow.Text = "Escaleno";
                    }

                }
                else
                {
                    this.Resultadow.Text = "Triângulo incapaz de ser formado.";
                }

            }
            else
            {
                MessageBox.Show("Apenas numeros!");
            }

        }

        private void Limpar_Click(object sender, EventArgs e)
        {
            this.A.Clear();
            this.B.Clear();
            this.C.Clear();
            this.Resultadow.Clear();
        }

        private void Sair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

