﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ativdade_2_Peso
{
    public partial class Form1 : Form
    {
        double altura, peso, resultado = 0;

     
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(maskedTextBox2.Text, out altura) || !double.TryParse(maskedTextBox1.Text, out peso))
            {
                MessageBox.Show("Digita Direito");
            }
            else
            {
                if (radioButton2.Checked)
                {
                    resultado = (62.1 * altura) - 44.7;
                    resultado = Math.Round(resultado, 2);
                    if (resultado == peso)
                    {
                        this.textBox1.Text = ("Peso show de bola!");
                    }
                    else if (peso > resultado)
                    {
                        this.textBox1.Text = ("Dieta que fala né?!");
                    }
                    else
                    {
                        this.textBox1.Text = ("Teu peso ta igual a Babi, La embaixo");
                    }
                }
                else
                {
                    resultado = (72.7 * altura) - 58;
                    resultado = Math.Round(resultado, 2);
                    if (resultado == peso)
                    {
                        this.textBox1.Text = ("Peso show de bola!");
                    }
                    else if (peso > resultado)
                    {
                        this.textBox1.Text = ("Dieta que fala né?");
                    }
                    else
                    {
                        this.textBox1.Text = ("Teu peso ta igual a Babi, La embaixo");
                 
                    }
                    { this.textBox2.Text = resultado.ToString(); 
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            maskedTextBox2.Clear();
            maskedTextBox1.Clear();
            textBox1.Clear();
            textBox2.Clear();
            maskedTextBox2.Focus();
        }
    }
}

