﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salarioow
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            lblMensagem.Visible = true;
            double salarioBruto = 0;

            if ((txtnome.Text == " ") || (txtnome.Text.Length < 3))
                MessageBox.Show("Nome Inválido");
            else if (!double.TryParse(mtxtsb.Text, out salarioBruto))
                MessageBox.Show("Salário Inválido");
            else
            {
                double descontoINSS = 0;
                double descontoIR = 0;
                double salarioFamilia = 0;
                double salarioLiquido = 0;

                    if (salarioBruto <= 800.47)
                {
                    txtinss.Text = "7.65%";
                    descontoINSS = 0.0765 * salarioBruto;
                }
                else if (salarioBruto <= 1050)
                {
                    txtinss.Text = "8.65%";
                    descontoINSS = 0.0865 * salarioBruto;
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtinss.Text = "9.00%";
                    descontoINSS = 0.09 * salarioBruto;
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtinss.Text = "11.00%";
                    descontoINSS = 0.011 * salarioBruto;
                }
                else if (salarioBruto > 2801.56)
                {
                    txtinss.Text = "308.17";
                    descontoINSS = salarioBruto - 308.17;
                }
                txtdinns.Text = descontoINSS.ToString("N2");

                if (salarioBruto <= 1257.12)
                {
                    txtirpf.Text = "Isento";
                    descontoIR = 0;
                }
                else if (salarioBruto <= 2512.08)
                {
                    txtirpf.Text = "15%";
                    descontoIR = 0.15 * salarioBruto;
                }
                else if (salarioBruto > 2512.08)
                {
                    txtirpf.Text = "27.5%";
                    descontoIR = 0.275 * salarioBruto;
                }

                txtdirpf.Text = descontoIR.ToString("N2");

                if (salarioBruto <= 435.52)
                {
                    txtsf.Text = "22.33 por filho";
                    salarioFamilia = Convert.ToDouble(cbox1.SelectedItem) * 22.33;
                }

                else if (salarioBruto <= 654.61)
                {
                    txtsf.Text = "15.74 por filho";
                    salarioFamilia = Convert.ToDouble(cbox1.SelectedItem) * 15.74;
                }

                else if (salarioBruto > 654.61)
                {
                    txtsf.Text = "0";
                    salarioFamilia = 0;
                }
                txtsf.Text = salarioFamilia.ToString("N2");

                salarioLiquido = (salarioBruto - descontoINSS - descontoIR) + salarioFamilia;
                txtsl.Text = salarioLiquido.ToString("N2");

                string texto = "Os descontos do Salário";

                if (rdbf.Checked)
                    texto = texto + " da Sra.";
                else
                    texto = texto + " do Sr.";

                if (cb1.Checked)
                    texto = texto + " que é casado(a)";
                else
                    texto = texto + " que é solteiro(a)";

                texto = texto + " e que tem " + cbox1.SelectedItem.ToString() + " Filho(s).";

                lblMensagem.Text = texto; 


            }
        }

        private void Sair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
