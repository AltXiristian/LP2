﻿
namespace Salarioow
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.txtinss = new System.Windows.Forms.TextBox();
            this.txtirpf = new System.Windows.Forms.TextBox();
            this.txtsf = new System.Windows.Forms.TextBox();
            this.txtsl = new System.Windows.Forms.TextBox();
            this.txtdinns = new System.Windows.Forms.TextBox();
            this.txtdirpf = new System.Windows.Forms.TextBox();
            this.mtxtsb = new System.Windows.Forms.MaskedTextBox();
            this.cbox1 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbm = new System.Windows.Forms.RadioButton();
            this.rdbf = new System.Windows.Forms.RadioButton();
            this.cb1 = new System.Windows.Forms.CheckBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.Sair = new System.Windows.Forms.Button();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(570, 273);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 13);
            this.label9.TabIndex = 28;
            this.label9.Text = "Desconto IRPF";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(570, 233);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 27;
            this.label8.Text = "Desconto INSS";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(49, 342);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "Salário Liquido";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(55, 307);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "Salário Familia";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(52, 273);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "Aliquota IRPF";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Aliquota INSS";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Numero de Filhos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(62, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Salário Bruto";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Nome do Funcionario";
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(158, 40);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(170, 20);
            this.txtnome.TabIndex = 29;
            // 
            // txtinss
            // 
            this.txtinss.Enabled = false;
            this.txtinss.Location = new System.Drawing.Point(146, 237);
            this.txtinss.Name = "txtinss";
            this.txtinss.Size = new System.Drawing.Size(100, 20);
            this.txtinss.TabIndex = 30;
            // 
            // txtirpf
            // 
            this.txtirpf.Enabled = false;
            this.txtirpf.Location = new System.Drawing.Point(146, 273);
            this.txtirpf.Name = "txtirpf";
            this.txtirpf.Size = new System.Drawing.Size(100, 20);
            this.txtirpf.TabIndex = 31;
            // 
            // txtsf
            // 
            this.txtsf.Enabled = false;
            this.txtsf.Location = new System.Drawing.Point(146, 307);
            this.txtsf.Name = "txtsf";
            this.txtsf.Size = new System.Drawing.Size(100, 20);
            this.txtsf.TabIndex = 32;
            // 
            // txtsl
            // 
            this.txtsl.Enabled = false;
            this.txtsl.Location = new System.Drawing.Point(146, 339);
            this.txtsl.Name = "txtsl";
            this.txtsl.Size = new System.Drawing.Size(100, 20);
            this.txtsl.TabIndex = 33;
            // 
            // txtdinns
            // 
            this.txtdinns.Enabled = false;
            this.txtdinns.Location = new System.Drawing.Point(657, 230);
            this.txtdinns.Name = "txtdinns";
            this.txtdinns.Size = new System.Drawing.Size(100, 20);
            this.txtdinns.TabIndex = 34;
            // 
            // txtdirpf
            // 
            this.txtdirpf.Enabled = false;
            this.txtdirpf.Location = new System.Drawing.Point(657, 273);
            this.txtdirpf.Name = "txtdirpf";
            this.txtdirpf.Size = new System.Drawing.Size(100, 20);
            this.txtdirpf.TabIndex = 35;
            // 
            // mtxtsb
            // 
            this.mtxtsb.Location = new System.Drawing.Point(158, 79);
            this.mtxtsb.Name = "mtxtsb";
            this.mtxtsb.Size = new System.Drawing.Size(100, 20);
            this.mtxtsb.TabIndex = 36;
            // 
            // cbox1
            // 
            this.cbox1.FormattingEnabled = true;
            this.cbox1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbox1.Location = new System.Drawing.Point(158, 114);
            this.cbox1.Name = "cbox1";
            this.cbox1.Size = new System.Drawing.Size(121, 21);
            this.cbox1.TabIndex = 37;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbf);
            this.groupBox1.Controls.Add(this.rdbm);
            this.groupBox1.Location = new System.Drawing.Point(573, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // rdbm
            // 
            this.rdbm.AutoSize = true;
            this.rdbm.Location = new System.Drawing.Point(30, 34);
            this.rdbm.Name = "rdbm";
            this.rdbm.Size = new System.Drawing.Size(34, 17);
            this.rdbm.TabIndex = 0;
            this.rdbm.TabStop = true;
            this.rdbm.Text = "M";
            this.rdbm.UseVisualStyleBackColor = true;
            // 
            // rdbf
            // 
            this.rdbf.AutoSize = true;
            this.rdbf.Location = new System.Drawing.Point(30, 57);
            this.rdbf.Name = "rdbf";
            this.rdbf.Size = new System.Drawing.Size(31, 17);
            this.rdbf.TabIndex = 1;
            this.rdbf.TabStop = true;
            this.rdbf.Text = "F";
            this.rdbf.UseVisualStyleBackColor = true;
            // 
            // cb1
            // 
            this.cb1.AutoSize = true;
            this.cb1.Location = new System.Drawing.Point(588, 177);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(86, 17);
            this.cb1.TabIndex = 39;
            this.cb1.Text = "Casada????";
            this.cb1.UseVisualStyleBackColor = true;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(158, 195);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 23);
            this.btn1.TabIndex = 40;
            this.btn1.Text = "Calcular";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // Sair
            // 
            this.Sair.Location = new System.Drawing.Point(682, 353);
            this.Sair.Name = "Sair";
            this.Sair.Size = new System.Drawing.Size(75, 23);
            this.Sair.TabIndex = 41;
            this.Sair.Text = "Sair";
            this.Sair.UseVisualStyleBackColor = true;
            this.Sair.Click += new System.EventHandler(this.Sair_Click);
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.Location = new System.Drawing.Point(160, 167);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(0, 13);
            this.lblMensagem.TabIndex = 42;
            this.lblMensagem.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.Sair);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.cb1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbox1);
            this.Controls.Add(this.mtxtsb);
            this.Controls.Add(this.txtdirpf);
            this.Controls.Add(this.txtdinns);
            this.Controls.Add(this.txtsl);
            this.Controls.Add(this.txtsf);
            this.Controls.Add(this.txtirpf);
            this.Controls.Add(this.txtinss);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "SalarioArio";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.TextBox txtinss;
        private System.Windows.Forms.TextBox txtirpf;
        private System.Windows.Forms.TextBox txtsf;
        private System.Windows.Forms.TextBox txtsl;
        private System.Windows.Forms.TextBox txtdinns;
        private System.Windows.Forms.TextBox txtdirpf;
        private System.Windows.Forms.MaskedTextBox mtxtsb;
        private System.Windows.Forms.ComboBox cbox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbf;
        private System.Windows.Forms.RadioButton rdbm;
        private System.Windows.Forms.CheckBox cb1;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button Sair;
        private System.Windows.Forms.Label lblMensagem;
    }
}

